   param (
         [parameter(Mandatory = $true)][string]$Munitfilepath
   )
    try
    {
    #Finding whether api is pxy type or standard
    $Apireponame = $Munitfilepath.split("/")[2]
    if($Apireponame -notmatch "pxy-api")
    
    {
        write-host "Identified api $APIreponame is standard type . Hence performing the munit validation"
        $Munitfile =  Get-ChildItem -Path "$Munitfilepath\*.xml" | Select-Object -First 1 -ExpandProperty name
        if($Munitfile)
            {
                write-host "$Munitfile is considered for the munit prevalidation"
                [xml]$Readvalue = Get-content -path "$Munitfilepath\$Munitfile"
                $configvalue = $Readvalue.mule.config
            if(!$configvalue)
            {
                throw "Prevalidation failed for munit test. Testfile $Munitfile is not defined as per the munit test standards"
                Exit 1
            }
        }
        else
            {
                throw "Prevalidation failed for munit test.Kindly add the valid munit testfiles in the directory and re trigger the deployment"
                Exit 1
            }
        Write-Host "Prevalidation successful for munit tests"
        }
    else
    {
        Write-host "Identified API   $Apireponame is proxy type and hence skipping the munit validation"
     }
    }
    catch
    {

        write-host "Prevalidation failed for munit because of following reason : $_ " -ForegroundColor Red
        Exit 1
    }
