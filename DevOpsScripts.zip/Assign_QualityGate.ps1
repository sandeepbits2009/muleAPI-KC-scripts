[CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$SonarServerName,
        [Parameter(Mandatory = $true)]$Sonartoken,
        [Parameter(Mandatory = $false)]$GateName = "Gold Gate",
        [Parameter(Mandatory = $true)]$SonarProjectKey
    )

    begin
        {
        write-host "######Being Step########"
        write-host "The value of url:" "$SonarServerName"
        write-host "The value of sonartoken:" $sonartoken
        write-host "The value of projectkey:" $SonarProjectKey
                
    }

    process
    {
    #region to skip sonarqube api certs warnings     
        add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
        [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    #endregion
        Write-host "######Process Step########"
        $AssigngateUrl = "$SonarServerName/api/qualitygates/select"
		$FetchGateIdUrl = "$SonarServerName/api/qualitygates/show"
        try {
            $Token = [System.Text.Encoding]::UTF8.GetBytes($SonarToken + ":")
            $TokenInBase64 = [System.Convert]::ToBase64String($Token)
            $basicAuth = [string]::Format("Basic {0}", $TokenInBase64)
            $Headers = @{ Authorization = $basicAuth }
            #Deciding the Quality Gate based on the project type .
			
            Write-host "Assigning quality gate $GateName to the project $SonarProjectKey"
			#Fetch quality gate id from gateName
			$body = @{ 
			
			    name="$GateName"
			}
			$InvokeURL = Invoke-RestMethod -Uri $FetchGateIdUrl -Method GET -Headers $Headers -Body $body -Erroraction Stop
            $GateID = $InvokeURL.id
            If($GateID)
            {	
			    Write-host "GateID fetched for the $GateName is $GateID"
            }
            else
            {
                throw "Unable to find the Quality ID for the $GateName . Please verify manually if QualityGate $GateName is present"
            }			
			
            $body = @{
                gateId = "$GateId"
                projectKey = "$SonarProjectKey"
            }
            Write-host "Assigning the qualityid $qualityid to the project $SonarProjectKey"
            $QualityGateResult = Invoke-RestMethod -Uri $Assigngateurl -Method 'Post' -Headers $headers -Body $body
            write-host "Successfully set QualityGate $gateName on Project $SonarProjectKey !!"
        }

        catch {
            write-host "Failed to execute QualityGate !" -ForegroundColor Red
            write-host $_.Exception.Message -ForegroundColor Red
            write-host $_.Exception.ItemName -ForegroundColor Red
            Exit 1
        }
        
    }

    end
    {
        Write-host "######End Step########"
        Write-host "Applied the QualityGate"
    }
