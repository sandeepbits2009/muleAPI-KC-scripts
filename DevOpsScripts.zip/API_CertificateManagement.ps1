<#
.SYNOPSIS
This script is used to  create and download certificate through API call
.PARAMETER Username
Username of Venafi server
.PARAMETER Password
Password of the Venafi server 
. PARAMETER CerticatePassword  
password for created certicate - 12 letters, 1 uppercase,1lowercase,1letter,1special character
.PARAMETER apiName
Name of the API, including its environment, for example kcc-testrepo1-dev , where kcc-testrepo1 is an api name and -dev is its environment as defined in mulesoft portal

.\API_CertificateManagement.ps1 -apiName 'kcc-cicd' -Username 'venafi' -Password 'abcd' -CerticatePassword 'KCCtesting@1234'
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]$Username,
    [Parameter(Mandatory = $true)]$Password,
    [Parameter(Mandatory = $true)]$apiName,
    [Parameter(Mandatory = $true)]$CertificatePassword,
    [Parameter(Mandatory = $true)] $PATToken,
    [Parameter(Mandatory = $true)] $DownloadPath
)

begin {

    
 }
process {      
try {
    #Get the access_token parameter from the AuthUrl
    $AuthUrl = "https://ustca708.kcc.com/vedauth/authorize" 
    $Headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $Headers.Add("Content-Type", "application/json")
    $body = "{
                        `"client_id`":`"api`",
                        `"username`": `"$Username`",
                        `"password`": `"$Password`",
                        `"scope`":`"certificate:discover,manage;configuration:manage`"
                    }"
    $Tokenresponse = Invoke-RestMethod -Uri $AuthUrl -Method 'POST' -Headers $Headers -Body $body
    # Write-Host "Token response :" $Tokenresponse
                             
    $Bearertoken = $Tokenresponse.access_token
    
                
    $Headers.Add("Authorization", "Bearer $Bearertoken") 
} 
catch {
    write-host "Failed to get the Bearer Token for the  $AuthUrl !" -ForegroundColor Red
    write-host $_.Exception.Message -ForegroundColor Red
}

try {
    # Create Certificate
    $Certificateapi = "https://ustca708.kcc.com/vedsdk/Certificates/Request"
    $PolicyDN = "\\VED\\Policy\\_Teams\\API-Platform (API-NA-KC)\\Internal Certificates\\K-C Web Server"
    $Subject = $apiName + ".venafi.example"
    $Body = "{
                    `"PolicyDN`":`"$PolicyDN`",
                    `"ObjectName`":`"$Subject`",
                    `"Subject`":`"$Subject`",
                    `"ManagementType`":`"Provisioning`",
                    `"SetWorkToDo`":true,
                 	`"CustomFields`": [{
		                            `"Name`": `"Service-Now Contact Group`",
		                            `"Values`": [`"API-SUPPORT-COG`"]
	                   }],
                     `"DisableAutomaticRenewal`":false
                }"
    $response = Invoke-RestMethod -Uri  $Certificateapi -Method POST -Headers $Headers -Body $Body 
    $CertificateDN = $response.CertificateDN
    Write-Host "Certificate:" $CertificateDN
            
}
catch {
    write-host "failed while creating  the Certificate from  $Certificateapi !" -ForegroundColor Red
    write-host $_.Exception.Message -ForegroundColor Red
}   
try {
    #Download Certificate
    #$Downloadapi="https://ustca708.kcc.com/vedsdk/Certificates/Retrieve?CertificateDN=\\VED\\Policy\\_Teams\\API-Platform (API-NA-KC)\\Internal Certificates\\K-C Web Server\\abc-api.venafi.example&Format=JKS&FriendlyName=abc-api.venafi.example&IncludeChain=true&IncludePrivateKey=true&KeystorePassword=Mule@1234567&Password=Mule@1234567"
    $constructstring = $CertificateDN + "&Format=JKS&FriendlyName=" + $CertificateDN + "&IncludeChain=true&IncludePrivateKey=true&KeystorePassword=" + $CertificatePassword + "&Password=" + $CertificatePassword
    $Downloadapi = "https://ustca708.kcc.com/vedsdk/Certificates/Retrieve?CertificateDN=$constructstring"
    while((!(Test-Path $DownloadPath)))
    {
        
        write-output "Downloading the cert from venafi.."
        Invoke-RestMethod -Uri  $Downloadapi  -Method GET -Headers $Headers -ErrorAction SilentlyContinue | Out-File $DownloadPath

    }
    write-host "Succesfully downloaded the certificate"
    write-host "Path to find the downloaded file: " $DownloadPath
}
catch {
    write-host "failed while  downloading the  Certificate from  $Downloadapi !" 
    write-host $_.Exception.Message 
}
try {
    #Upload the downloaded Certificate to Certs Folder in the Repository
    if ($null -ne $PATToken) {
        Write-Host "### Initialize authentication context ###" -ForegroundColor Yellow
        $token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($PATToken)"))
        $header = @{authorization = "Basic $token" }
        }
    $builddirectory = $Env:AGENT_BUILDDIRECTORY
    $branch = $Env:BUILD_SOURCEBRANCHNAME
    cd $builddirectory\s\ 
    git config --global user.email "IABOAP03@kcc.com"
    git config --global user.name "IA IT Centre Bangalore GDTC Engineering - DevOps Azure Devops"
    git config --global advice.detachedHead false
    git checkout $branch
    git  -c http.extraHeader="Authorization: Basic $token" pull origin $branch -f -v 
    $source = "$DownloadPath"
    $destination = "src\main\resources\certs\"
    Copy-Item -Path $source -Destination $destination -Recurse -Verbose
    git init
    git config --global user.email "IABOAP03@kcc.com"
    git config --global user.name "IA IT Centre Bangalore GDTC Engineering - DevOps Azure Devops"
    git config --global advice.detachedHead false
    #Push the changes 
    git add *
    git commit -am "[skip ci] Committing the downloaded Certificate to Certs folder"
    git -c http.extraHeader="Authorization: Basic $token" push origin HEAD:$branch -f -v
}
catch {
    write-host $_.Exception.Message 
}  
}

end {
        Write-host "`n ####### --- Task Complete: Create and download  Certificate  is Complete --- ######## `n"
}