﻿ function Get-BearerAccessToken {
  
   [cmdletbinding()]
    param (
            [parameter(Mandatory = $true)][string]$ClientId,
            [parameter(Mandatory = $true)][string]$ClientSecret
    )

    begin {
            Write-Host "Function Entry: Get-BearerAccessToken"
            Write-Host "*************************************"
    }
    process {               
            $AnyPointUrl         = "https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token" ;
            $GrantType           = "client_credentials";
            $ContentType         = "application/x-www-form-urlencoded"
            $TokenRequestPayload = "client_id=$ClientId&client_secret=$ClientSecret&grant_type=$GrantType"
            write-host "Token Request Payload :" $TokenRequestPayload
            write-host "AnyPointUrl           :" $AnyPointUrl
                             
            try {
                        #Get the access_token parameter from the Get Anypoint Url
                        $Tokenresponse = Invoke-RestMethod -Uri $AnyPointUrl -Method POST -Body $TokenRequestPayload -ContentType $ContentType -ErrorVariable oErr;
                        Write-Host "Token response :" $Tokenresponse
                        
                        $Bearertoken = $Tokenresponse.access_token
                        Write-Host "Bearer token   :" $Bearertoken
                        return $Bearertoken
            } 
            catch {
                        write-host "Failed to get the Bearer Token for the $AnyPointUrl !" -ForegroundColor Red
                        write-host $_.Exception.Message -ForegroundColor Red
						$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
						write-host $errorresponse -ForegroundColor Red
		                Exit 1
            }
    }
    end {
            Write-Host "Function Exit: Get-BearerAccessToken"
            Write-Host "*************************************"
    }
}
    
function Promote-APIManagerEntry{
    
    [cmdletbinding()]
    param (
        [parameter(Mandatory = $true)][string]$Bearertoken,    
        [parameter(Mandatory = $true)][string]$OrgId,
        [parameter(Mandatory = $true)][string]$EnvId,
        [parameter(Mandatory = $true)][string]$OriginApiId
    )

    begin {
                Write-Host "Function Entry:  Promote-APIManagerEntry"
                Write-Host "***************************************"
                Write-Host "Bearertoken   :" $Bearertoken             
    }
    process {
                $Policies    = "true";
                $Tiers       = "true";
                $ContentType = "application/json"
                $APIMgrUrl   = "https://anypoint.mulesoft.com/apimanager/api/v1/organizations/$OrgId/environments/$EnvId/apis" ;

                $Headers     = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $Headers.Add("Authorization", "Bearer $Bearertoken")

                $APIMgrRequestPayload = "{ `"instanceLabel`": null,
                                           `"promote`": {
                                           `"alerts`": {
                                                `"allEntities`": true
                                                },
                                           `"originApiId`": $OriginApiId,
                                           `"policies`": {
                                                 `"allEntities`": $Policies
                                                },
                                           `"tiers`": {
                                                 `"allEntities`": $Tiers
                                                }
                                            }
                                        }"               
                try {
                    # Promoting an entry in the API Manager
                    $APIMgrResponse = Invoke-RestMethod -Uri $APIMgrUrl -Method POST -header $Headers -Body $APIMgrRequestPayload -ContentType $ContentType -ErrorVariable oErr;
                    Write-Host "$APIMgrResponse : " $APIMgrResponse
                    
                    $APIMgrResponseId = $APIMgrResponse.id
                    write-host "API Manager ResponseID : " $APIMgrResponse.id
               
                    if($APIMgrResponseId) {
                        write-host "API Manager Promotion Sucessfully completed, Newly created API ID: " $APIMgrResponseId
                        Write-Host "##vso[task.setvariable variable=APIMgrResponseId]$APIMgrResponseId"
                        return $APIMgrResponseId
                       }
                } 
                catch {
                        write-host "Failed to promote the entry in the API Manager $APIMgrUrl !" -ForegroundColor Red
                        write-host $_.Exception.Message -ForegroundColor Red
			$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
			write-host $errorresponse -ForegroundColor Red
		        Exit 1
               }
    }
    end {
            Write-Host "Function Exit:  Promote-APIManagerEntry"
            Write-Host "**************************************"
    }
}           

  $ClientId      = $args[0]
  $ClientSecret  = $args[1]
  $OrgId         = $args[2]
  $EnvId         = $args[3]
  $OriginApiId   = $args[4]

# Getting the Bearer Access Token        
  $Bearertoken = Get-BearerAccessToken -ClientId $clientId -ClientSecret $ClientSecret
  Write-Host "Bearertoken   :" $Bearertoken

  # Promoting the entry in the API Manager
  if($Bearertoken -ne $null) { 
    $APIMgrResponseId = Promote-APIManagerEntry -Bearertoken $Bearertoken -OrgId $OrgId -EnvId $EnvId -OriginApiId $OriginApiId
    #Write-Host "##vso[task.setvariable variable=DevApiId]$APIMgrResponseId"
  }
  else
  {
    write-host "Bearer Token for the $AnyPointUrl is empty !" -ForegroundColor Red
    write-host $_.Exception.Message -ForegroundColor Red
    write-host $_.Exception.ItemName -ForegroundColor Red 
  }