﻿<#
.SYNOPSIS
Compare vCore Script will compare vcores in sandbox and prodcution and if no available vcores, it breaks the build 

.PARAMETER Client_np_Secret
Non prod client secret to fetch app status and vcore connection

.PARAMETER Client_p_secret
Prod client secret to fetch app status and vcore connection

.PARAMETER Domain
Input to accept the api name

All the remaining environment and client variables are fetched internally by the script using environment variable and assign it accordingly
.EXAMPLE
.$(Agent.BuildDirectory)/s/Compare-vCore.ps1 $(CA_NP_Client_Secret)  $(CA_P_Client_Secret) $(Domain)
#>
$orgId = $env:ORG_ID
$client_np_secret = $args[0]
$client_p_secret = $args[1]
$domain = $args[2]
$branchName = $env:Build_SourceBranch.split("/")[2]
$hashTable = @{}
$zeroprodvcore = $false
$zerosandboxvcore = $false
write-host "branch name: $branchName"
write-host "domainname: $domain"
if ($env:Build_SourceBranch -match "refs/heads/hotfix-*")
{
  $branchname = 'hotfix'
}

function Get-BearerAccessToken {

  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true)] [string]$ClientId,
    [Parameter(Mandatory = $true)] [string]$ClientSecret
  )

 
    $AnyPointUrl = "https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token";
    $GrantType = "client_credentials";
    $ContentType = "application/x-www-form-urlencoded"
    $TokenRequestPayload = "client_id=$ClientId&client_secret=$ClientSecret&grant_type=$GrantType"
   

    try {
      #Get the access_token parameter from the Get Anypoint Url
      $Tokenresponse = Invoke-RestMethod -Uri $AnyPointUrl -Method POST -Body $TokenRequestPayload -ContentType $ContentType -ErrorVariable oErr;
      Write-Host "Token response :" $Tokenresponse

      $Bearertoken = $Tokenresponse.access_token
      return $Bearertoken
    }
    catch {
      Write-Host "Failed to get the Bearer Token for the $AnyPointUrl !" -ForegroundColor Red
      Write-Host $_.Exception.Message -ForegroundColor Red
      $errorresponse = $oErr.Message | ConvertFrom-Json | Out-String
      Write-Host $errorresponse -ForegroundColor Red
      exit 1
    }
  
  
}

function Get-ApplicationName {

  param(

    $domain,
    $BearerToken,
    $orgId,
    $EnvID,
    $clientId,
    $clientSecret
  )

  $Bearertoken = Get-BearerAccessToken -ClientId $clientId -ClientSecret $ClientSecret
  #return $BearerToken

  $ApplicationUrl = "https://anypoint.mulesoft.com/cloudhub/api/v2/applications/$domain";
  $Headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $Headers.Add("Authorization","Bearer $Bearertoken")
  $Headers.Add("X-ANYPNT-ORG-ID","$OrgId")
  $Headers.Add("X-ANYPNT-ENV-ID","$EnvId")

  #Get the access_token parameter from the Get Anypoint Url     
  try {
    $Initialresponse = Invoke-RestMethod -Uri $ApplicationUrl -Method GET -Headers $Headers -ErrorAction stop -ErrorVariable oErr
    $Initialstate = $Initialresponse.domain
    $InitialStatus = $Initialresponse.status
    if ($Initialstate) {
      $apiexists = 0
      # Write-host "Application Deployment Status : " $InitialStatus
      return $Initialstatus
    }
  }

  catch {
    $statusCodeValue = $_.Exception.Response.StatusCode.value__
    Write-Host $_.Exception.Message -ForegroundColor Red
    return "FIRSTTIME"
    Write-host "Application not deployed and setting it as FIRSTTIME deployment"
  }

}

#mapping environment id to each environment
$environmentmap = @{
  dev = $env:env_dev_id
  uat = $env:env_uat_id
  prod = $env:env_prod_id
  qa = $env:env_qa_id
  pdv = $env:env_predev_id

}

#branch to api domain mapping
$branchmapping = @{
  dev = "$domain-dev"
  master = "$domain-uat","$domain-prod"
  hotfix = "$domain-dev","$domain-uat","$domain-prod"
  "pre-dev" = "$domain-pdv"
  qa = "$domain-qa"

}

#fetching the available domains based on the branch
$apiList = $branchmapping[$branchName]

foreach ($api in $apiList)
{
  write-host "Current api name from the list $api"
  if ($api.EndsWith("-prod"))
  {
    $environment = "prod"
    $ClientId = $env:ca_p_client_id
    $ClientSecret = $client_p_secret
    $api = $domain
  }
  else
  {
    $ClientId = $env:ca_np_client_id
    $ClientSecret = $client_np_secret
    $environment = $api.split("-")[-1]
  }


  
  #fetching the api status 
  
  Write-Host "Fetching the $api status" 
  $Status = Get-ApplicationName -domain $api -BearerToken $BearerToken -orgId $orgID -envID $environmentmap[$environment] -ClientId $ClientId -ClientSecret $ClientSecret
  Write-Host "$api status returned as $Status"
  $hashTable += @{ $api = "$status" }

}

#region to fetch the assigned and consumed vcores

$Bearertoken = Get-BearerAccessToken -ClientId $clientid -ClientSecret $ClientSecret
$Headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$Headers.Add("Authorization","Bearer $Bearertoken")
$vCoreAssigned = Invoke-RestMethod -Method Get -Uri https://anypoint.mulesoft.com/accounts/api/organizations/$orgId -Headers $Headers
$vCoreConsumed = Invoke-RestMethod -Method Get -Uri https://anypoint.mulesoft.com/cloudhub/api/organizations/$orgId/usage -Headers $Headers
$ASVC = [decimal]$vCoreAssigned.entitlements.vCoresSandbox.assigned - $vCoreConsumed.sandboxVCoresConsumed
$APVC = [decimal]$vCoreAssigned.entitlements.vCoresProduction.assigned - $vCoreConsumed.productionVCoresConsumed

foreach ($key in $hashTable.keys)
{
  if (($key -notmatch "dev|uat|pdv|qa") -and ($hashtable[$key] -match "UNDEPLOYED|FIRSTTIME"))
  {

    if ($APVC -eq 0)
    {
      $zeroprodvcore = $true
    }

  }
  elseif (($key -match "dev|uat|pdv|qa") -and ($hashtable[$key] -match "UNDEPLOYED|FIRSTTIME"))
  {

    if ($ASVC -eq 0)
    {
      $zerosandboxvcore = $true
    }
  }
}

if (($zeroprodvcore -eq $true) -and ($env:System_StageName -eq "PROD_PreValidation"))
{
  
      Write-Host "--- ### The total available  Production vCores is $APVC ### ---" 
      Write-Host "##vso[task.logissue type=error]Pre-Validation Stage failed as the Available Production vCores  is $APVC." 
      Write-Host "##vso[task.setvariable variable=vcorefailure]true"
      Write-Host "##vso[task.logissue type=warning]Pre-Validation Stage failed as the Available Porduction vCores  is $ASVC."

}
elseif (($zerosandboxvcore -eq $true) -and ($env:System_StageName -eq "PreValidation"))
{
      Write-Host "--- ### The total available  Sandbox vCores is $ASVC ### ---" 
      Write-Host "##vso[task.logissue type=error]Pre-Validation Stage failed as the Available Sandbox vCores  is $ASVC."
      exit 1
}



