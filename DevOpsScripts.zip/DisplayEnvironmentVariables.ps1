[CmdletBinding()]
param()

# ---------------------------------------------------------------------------------------------
#
#  main program
#
# ---------------------------------------------------------------------------------------------


# clear the screen
clear-host

#[Environment]::SetEnvironmentVariable("TERM", "xterm-256color", "Machine")
$env:TERM = "xterm-256color"

# get all the environment variables
$environmentVariables = Get-ChildItem env:

# get the maximum length of the keys
$maxLength = 0
$environmentVariables | foreach-object { if($_.Key.Length -gt $maxLength) {$maxLength = $_.Key.Length}}

# create a format that will make it look nice
$format = "{{0, {0}}}: {{1}}" -f (0 - ($maxLength + 1))

# output the variables
$environmentVariables | sort-object -Property Key | foreach-object { Write-Host ($format -f $_.Key, $_.Value) }