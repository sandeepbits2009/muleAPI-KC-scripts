﻿function Get-BearerAccessToken {
  
   [cmdletbinding()]
    param (
             [parameter(Mandatory = $true)][string]$ClientId,
             [parameter(Mandatory = $true)][string]$ClientSecret
    )

    begin {
               Write-Host "Function Entry: Get-BearerAccessToken"
               Write-Host "*************************************"
    }
    process {               
               $AnyPointUrl         = "https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token" ;
               $GrantType           = "client_credentials";
               $ContentType         = "application/x-www-form-urlencoded"
               $TokenRequestPayload = "client_id=$ClientId&client_secret=$ClientSecret&grant_type=$GrantType"
               write-host "Token Request Payload :" $TokenRequestPayload
                             
               try {
                        #Get the access_token parameter from the Get Anypoint Url
                        $Tokenresponse = Invoke-RestMethod -Uri $AnyPointUrl -Method POST -Body $TokenRequestPayload -ContentType $ContentType -ErrorVariable oErr;
                        Write-Host "Token response :" $Tokenresponse
                        
                        $Bearertoken = $Tokenresponse.access_token
                        Write-Host "Bearer token   :" $Bearertoken
                        return $Bearertoken
               } 
               catch {
                        write-host "Failed to get the Bearer Token for the $AnyPointUrl !" -ForegroundColor Red
                        write-host $_.Exception.Message -ForegroundColor Red
						$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
						write-host $errorresponse -ForegroundColor Red
		                Exit 1
               }
    }
    end {
            Write-Host "Function Exit: Get-BearerAccessToken"
            Write-Host "*************************************"
    }
}

function Get_APIID { 

[cmdletbinding()]
    param (
            [parameter(Mandatory = $true)][string]$Bearertoken,
            [parameter(Mandatory = $true)][string]$OrgId,
            [parameter(Mandatory = $true)][string]$EnvId,
            [parameter(Mandatory = $true)][string]$ApplicationName
    )

    begin {
               Write-Host "Function Entry: Get-APIID"
               Write-Host "*************************************"
               Write-Host "Bearertoken       :" $Bearertoken
               Write-Host "OrganisationId    :" $OrgId
               Write-Host "Environment Id    :" $EnvId
               Write-Host "Application Name  :" $ApplicationName
    }
    process {               
               $ApplicationUrl  = "https://anypoint.mulesoft.com/cloudhub/api/v2/applications/$ApplicationName" ;
                        
               $Headers     = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
               $Headers.Add("Authorization", "Bearer $Bearertoken")
               $Headers.Add("X-ANYPNT-ORG-ID" , "$OrgId")
               $Headers.Add("X-ANYPNT-ENV-ID" , "$EnvId")
          
               #Get the access_token parameter from the Get Anypoint Url     
               try {
                        $Deploymentresponse = Invoke-RestMethod -Uri $ApplicationUrl -Method GET -Headers $Headers -ErrorVariable oErr;
                        $Domainstate        = $Deploymentresponse.domain
                        $Deploymentprops    = $Deploymentresponse.properties
                        
                        write-host "API Properties:" $Deploymentprops
                        $apiid = "api.id"
                        $currentapiid = $Deploymentprops.$apiid
                        
                        if($currentapiid -eq "") {
                          write-host "Current API ID of the application returned null"
                        }
                        write-host "Existing Application ID: " $currentapiid
                        Write-Host "##vso[task.setvariable variable=currentapiid]$currentapiid"   
                   } 
               catch {
                        write-host $_.Exception.Message -ForegroundColor Red
						$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
						write-host $errorresponse -ForegroundColor Red
                        Exit 1
                     }
    }
   
    end {
            Write-Host "Function Exit: Get-APIID"
            Write-Host "*************************************"
    }
}

 $ClientId      = $args[0]
 $ClientSecret  = $args[1]
 $OrgId         = $args[2]
 $EnvId         = $args[3]
 $ApplicationName   = $args[4]

# Getting the Bearer Access Token        
  $Bearertoken = Get-BearerAccessToken -ClientId $clientId -ClientSecret $ClientSecret
  Write-Host "Bearertoken   :" $Bearertoken

  # Promoting the entry in the API Manager
  if($Bearertoken -ne $null) { 
      $APIID = Get_APIID -Bearertoken $Bearertoken -OrgId $OrgId -EnvId $EnvId -ApplicationName $ApplicationName
      write-host $APIID
  }