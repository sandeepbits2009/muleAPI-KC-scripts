﻿function Get-BearerAccessToken {
  
   [cmdletbinding()]
    param (
             [parameter(Mandatory = $true)][string]$ClientId,
             [parameter(Mandatory = $true)][string]$ClientSecret
    )

    begin {
               Write-Host "Function Entry: Get-BearerAccessToken"
               Write-Host "*************************************"
    }
    process {               
               $AnyPointUrl         = "https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token" ;
               $GrantType           = "client_credentials";
               $ContentType         = "application/x-www-form-urlencoded"
               $TokenRequestPayload = "client_id=$ClientId&client_secret=$ClientSecret&grant_type=$GrantType"
               write-host "Token Request Payload :" $TokenRequestPayload
                             
               try {
                        #Get the access_token parameter from the Get Anypoint Url
                        $Tokenresponse = Invoke-RestMethod -Uri $AnyPointUrl -Method POST -Body $TokenRequestPayload -ContentType $ContentType -ErrorVariable oErr;
                        Write-Host "Token response :" $Tokenresponse
                        
                        $Bearertoken = $Tokenresponse.access_token
                        Write-Host "Bearer token   :" $Bearertoken
                        return $Bearertoken
               } 
               catch {
                        write-host "Failed to get the Bearer Token for the $AnyPointUrl !" -ForegroundColor Red
                        write-host $_.Exception.Message -ForegroundColor Red
						$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
						write-host $errorresponse -ForegroundColor Red
		                Exit 1
               }
    }
    end {
            Write-Host "Function Exit: Get-BearerAccessToken"
            Write-Host "*************************************"
    }
}
    
function Deploy-API{
    
    [cmdletbinding()]
    param (
         [parameter(Mandatory = $true)][string]$Bearertoken,
         [parameter(Mandatory = $true)][string]$OrgId,
         [parameter(Mandatory = $true)][string]$EnvId,
         [parameter(Mandatory = $true)][string]$apiId,
         [parameter(Mandatory = $true)][string]$anypointplatformclient_id,
         [parameter(Mandatory = $true)][string]$anypointplatformclient_secret,
         [parameter(Mandatory = $true)][string]$multipartFile,
         [parameter(Mandatory = $true)][string]$jsonFilePath
    )

    begin {
                Write-Host "Function Entry:  Deploy-API"
                Write-Host "***************************"
                Write-Host "Bearertoken   :" $Bearertoken
                Write-Host "OrganisationId:" $OrgId
                Write-Host "Environment Id:" $EnvId
                Write-Host "Application Id:" $apiId
                Write-Host "Application Path:" $multipartFile
                Write-Host "Json File Path:" $jsonFilePath
                               
       }
     process {      
                $APIDeployUrl= "https://anypoint.mulesoft.com/cloudhub/api/v2/applications";
                Write-Host "API Deployment Url:" $APIDeployUrl
               
                Add-Type -AssemblyName System.Net.Http
             
                $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $headers.Add("Authorization", "Bearer $Bearertoken")
                $headers.Add("X-ANYPNT-ORG-ID", "$OrgId")
                $headers.Add("X-ANYPNT-ENV-ID", "$EnvId")
                $headers.Add("Content-Type", "Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryjHyXiEssIibTqjfu")

                $multipartContent = [System.Net.Http.MultipartFormDataContent]::new()
                $stringHeader = [System.Net.Http.Headers.ContentDispositionHeaderValue]::new("form-data")
                $stringHeader.Name = "appInfoJson"
                $jsonfilecontent = get-content -path $jsonFilePath | ConvertFrom-Json
                $jsonfilecontent.properties.'api.id' = $apiId
                $jsonfilecontent.properties.'anypoint.platform.client_id' = $anypointplatformclient_id
                $jsonfilecontent.properties.'anypoint.platform.client_secret' = $anypointplatformclient_secret
                              
                $jsonfilecontent = $jsonfilecontent | ConvertTo-Json 
                write-host "Json File Content: " $jsonfilecontent 
                $StringContent = [System.Net.Http.StringContent]::new($jsonfilecontent)
                                
                $StringContent.Headers.ContentDisposition = $stringHeader
                $multipartContent.Add($stringContent)

                $stringHeader = [System.Net.Http.Headers.ContentDispositionHeaderValue]::new("form-data")
                $stringHeader.Name = "autoStart"
                $StringContent = [System.Net.Http.StringContent]::new("true")
                $StringContent.Headers.ContentDisposition = $stringHeader
                $multipartContent.Add($stringContent)

                write-host "API File Path: " $multipartFile
                $multipartFileName = Split-Path $multipartFile -leaf
                write-host "API File Name: " $multipartFileName
                $FileStream = [System.IO.FileStream]::new($multipartFile, [System.IO.FileMode]::Open)
                $fileHeader = [System.Net.Http.Headers.ContentDispositionHeaderValue]::new("form-data")
                $fileHeader.Name = "file"
                $fileHeader.FileName = $multipartFileName
                $fileContent = [System.Net.Http.StreamContent]::new($FileStream)
                $fileContent.Headers.ContentDisposition = $fileHeader
                $multipartContent.Add($fileContent)

                $body = $multipartContent
                                
                # Deploy API to the Cloud Hub
                try {
                        $response = Invoke-RestMethod -Uri $APIDeployUrl -Method 'POST' -Headers $headers -Body $body -ErrorVariable oErr
                        $response | ConvertTo-Json    
                        Write-Host "API Deploy Response : " $response
                        
                    } 
                catch {
                        write-host "Failed to deploy the API $APIDeployUrl !" -ForegroundColor Red
                        write-host $_.Exception.Message -ForegroundColor Red
						$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
						write-host $errorresponse -ForegroundColor Red
		                Exit 1
               }
    }
    end {
             Write-Host "Function Exit:  Deploy-API"
             Write-Host "**************************"
             return $response
    }
}

function Update-API{
    
    [cmdletbinding()]
    param (
         [parameter(Mandatory = $true)][string]$Bearertoken,    
         [parameter(Mandatory = $true)][string]$OrgId,
         [parameter(Mandatory = $true)][string]$EnvId,
         [parameter(Mandatory = $true)][string]$apiId,
         [parameter(Mandatory = $true)][string]$domain, 
         [parameter(Mandatory = $true)][string]$anypointplatformclient_id,
         [parameter(Mandatory = $true)][string]$anypointplatformclient_secret,
         [parameter(Mandatory = $true)][string]$multipartFile,
         [parameter(Mandatory = $true)][string]$jsonFilePath
    ) 

    begin {
                Write-Host "Function Entry:  Update-API"
                Write-Host "***************************"
                Write-Host "Bearertoken       :" $Bearertoken
                Write-Host "OrganisationId    :" $OrgId
                Write-Host "Environment Id    :" $EnvId
                Write-Host "Application Id    :" $apiId
                Write-Host "Domain            :" $domain
                Write-Host "Application Path  :" $multipartFile
                Write-Host "Json File Path    :" $jsonFilePath

          }
    process {      
                $APIUpdateUrl= "https://anypoint.mulesoft.com/cloudhub/api/v2/applications/$domain";
                write-host "API Update Url : " $APIUpdateUrl
                Add-Type -AssemblyName System.Net.Http

                $Headers     = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $Headers.Add("Authorization", "Bearer $Bearertoken")
                $Headers.Add("X-ANYPNT-ORG-ID" , "$OrgId")
                $Headers.Add("X-ANYPNT-ENV-ID" , "$EnvId")
                $headers.Add("Content-Type", "Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryjHyXiEssIibTqjfu")
                                        
                $multipartContent = [System.Net.Http.MultipartFormDataContent]::new()
                $stringHeader = [System.Net.Http.Headers.ContentDispositionHeaderValue]::new("form-data")
                $stringHeader.Name = "appInfoJson"
                $jsonfilecontent = get-content -path $jsonFilePath | ConvertFrom-Json
                $jsonfilecontent.properties.'api.id' = $apiId
                $jsonfilecontent.properties.'anypoint.platform.client_id' = $anypointplatformclient_id
                $jsonfilecontent.properties.'anypoint.platform.client_secret' = $anypointplatformclient_secret

                $jsonfilecontent = $jsonfilecontent | ConvertTo-Json 
                write-host "Json File Content: " $jsonfilecontent 
                $StringContent = [System.Net.Http.StringContent]::new($jsonfilecontent)
                                
                $StringContent.Headers.ContentDisposition = $stringHeader
                $multipartContent.Add($stringContent)

                $stringHeader = [System.Net.Http.Headers.ContentDispositionHeaderValue]::new("form-data")
                $stringHeader.Name = "autoStart"
                $StringContent = [System.Net.Http.StringContent]::new("true")
                $StringContent.Headers.ContentDisposition = $stringHeader
                $multipartContent.Add($stringContent)

                write-host "API File Path: " $multipartFile
                $multipartFileName = Split-Path $multipartFile -leaf
                write-host "API File Name: " $multipartFileName
                $FileStream = [System.IO.FileStream]::new($multipartFile, [System.IO.FileMode]::Open)
                $fileHeader = [System.Net.Http.Headers.ContentDispositionHeaderValue]::new("form-data")
                $fileHeader.Name = "file"
                $fileHeader.FileName = $multipartFileName
                $fileContent = [System.Net.Http.StreamContent]::new($FileStream)
                $fileContent.Headers.ContentDisposition = $fileHeader
                $multipartContent.Add($fileContent)

                $body = $multipartContent
                                                                  
                # Update API to the Cloud Hub
                try {
                        $APIUpdateResponse = Invoke-RestMethod -Uri $APIUpdateUrl -Method PUT -header $Headers -Body $body -ErrorVariable oErr; 
                        $APIUpdateResponse | ConvertTo-Json
                        Write-Host ("Application {0} is updating ..." -f $domain)
                        Write-Host "$APIUpdateResponse : " $APIUpdateResponse
                    } 
               catch {
                        write-host "Failed to update the API $APIUpdateUrl !" -ForegroundColor Red
                        write-host $_.Exception.Message -ForegroundColor Red
						$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
						write-host $errorresponse -ForegroundColor Red
		                Exit 1
                     }
        }
    end {
             Write-Host "Function Exit:  Update-API"
             Write-Host "**************************"
             return $APIUpdateResponse
    }
}

function Get-APIDeployStatus {
  
   [cmdletbinding()]
    param (
            [parameter(Mandatory = $true)][string]$Bearertoken,
            [parameter(Mandatory = $true)][string]$OrgId,
            [parameter(Mandatory = $true)][string]$EnvId,
            [parameter(Mandatory = $true)][string]$ApplicationName
    )

    begin {
               Write-Host "Function Entry: Get-APIDeployStatus"
               Write-Host "*************************************"
               Write-Host "Bearertoken       :" $Bearertoken
               Write-Host "OrganisationId    :" $OrgId
               Write-Host "Environment Id    :" $EnvId
               Write-Host "Application Name  :" $ApplicationName
    }
    process {               
               $ApplicationUrl  = "https://anypoint.mulesoft.com/cloudhub/api/v2/applications/$ApplicationName" ;
                        
               $Headers     = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
               $Headers.Add("Authorization", "Bearer $Bearertoken")
               $Headers.Add("X-ANYPNT-ORG-ID" , "$OrgId")
               $Headers.Add("X-ANYPNT-ENV-ID" , "$EnvId")
          
               #Get the access_token parameter from the Get Anypoint Url     
               try {
                        $Deploymentresponse = Invoke-RestMethod -Uri $ApplicationUrl -Method GET -Headers $Headers -ErrorVariable oErr;
                        $Domainstate        = $Deploymentresponse.domain
                        $DeploymentStatus   = $Deploymentresponse.status
                        
                        if($Domainstate) {    
                        #Setting the value to 0 if the API already exists else 1
                        $apiexists = 0
                        
                        $Timeout = 60
                        $timer = [Diagnostics.Stopwatch]::StartNew()
                                                                                                 
                        While (($timer.Elapsed.TotalSeconds -lt $Timeout) -and (($DeploymentStatus -eq 'UNDEPLOYED') -or ($DeploymentStatus -eq 'DEPLOYING'))) 
                            {
                                Write-Host ("Application {0} is starting ..." -f $ApplicationName)
                                Start-Sleep 10;

                                $Deploymentresponse = Invoke-RestMethod -Uri $ApplicationUrl -Method GET -Headers $Headers -ErrorVariable oErr;
                                $DeploymentStatus = $Deploymentresponse.status;
                            }
                        $timer.Stop()

                        $Deploymentresponse = Invoke-RestMethod -Uri $ApplicationUrl -Method GET -Headers $Headers -ErrorVariable oErr;  
                        $DeploymentStatus   = $Deploymentresponse.status                 
                        Write-Host "Deployment Status  :" $DeploymentStatus;
                        }
                    
                     } 
               catch {
                        $apiexists = 1                                                                         
                        write-host $_.Exception.Message -ForegroundColor Red
                        write-host $_.Exception.ItemName -ForegroundColor Red
                     }
    }
   
    end {
            Write-Host "Function Exit: Get-APIDeployStatus"
            Write-Host "*************************************"
            return $apiexists 
    }
}
    

  $ClientId      = $args[0]
  $ClientSecret  = $args[1]
  $OrgId         = $args[2]
  $EnvId         = $args[3]
  $domain        = $args[4]
  $ApiId         = $args[5]
  $anypointplatformclient_id = $args[6]
  $anypointplatformclient_secret = $args[7]
  $ApiFilePath   = $args[8]
  $jsonFilePath  = $args[9]
 
  # Getting the Bearer Access Token        
  $Bearertoken = Get-BearerAccessToken -ClientId $clientId -ClientSecret $ClientSecret
  Write-Host "Bearertoken   :" $Bearertoken

  $ApplicationUrl  = "https://anypoint.mulesoft.com/cloudhub/api/v2/applications/$domain" ;
  $Headers     = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $Headers.Add("Authorization", "Bearer $Bearertoken")
  $Headers.Add("X-ANYPNT-ORG-ID" , "$OrgId")
  $Headers.Add("X-ANYPNT-ENV-ID" , "$EnvId")
          
  #Get the access_token parameter from the Get Anypoint Url     
  try {
        $Initialresponse = Invoke-RestMethod -Uri $ApplicationUrl -Method GET -Headers $Headers -ErrorVariable oErr;
        $Initialstate    = $Initialresponse.domain
        $InitialStatus   = $Initialresponse.status
        if($Initialstate) {
            $apiexists = 0
            Write-host "Application Deployment Status : " $InitialStatus
        }
   }
   catch {
            $apiexists = 1     
            write-host $_.Exception.Message -ForegroundColor Red
			$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
			write-host $errorresponse -ForegroundColor Red
   }

  if($apiexists -eq 1) {
      # Deploying the Application
      $APIDeployResponse = Deploy-API -Bearertoken $Bearertoken -OrgId $OrgId -EnvId $EnvId -ApiId $ApiId -anypointplatformclient_id $anypointplatformclient_id -anypointplatformclient_secret $anypointplatformclient_secret -multipartFile $ApiFilePath -jsonFilePath $jsonFilePath
      $APIDeployStatus = $APIDeployResponse.status;
      
      # Get the Application Deployment Status of the API if the API deployment is initiated
      if($APIDeployStatus -eq "UNDEPLOYED")
      {
          $apiexists = Get-APIDeployStatus -OrgId $OrgId -EnvId $EnvId -ApplicationName $domain -Bearertoken $Bearertoken
          write-host "API Deployment Status:" $apiexists 
      }
  } 
  else
  {
      # Updating the Application
      $APIUpdateResponse = Update-API -Bearertoken $Bearertoken -OrgId $OrgId -EnvId $EnvId -ApiId $ApiId -domain $domain -anypointplatformclient_id $anypointplatformclient_id -anypointplatformclient_secret $anypointplatformclient_secret -multipartFile $ApiFilePath -jsonFilePath $jsonFilePath
      $APIUpdateStatus = $APIUpdateResponse.status;
      write-host "API Deployment Status: " $APIupdateStatus
  }