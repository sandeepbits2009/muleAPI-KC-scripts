﻿[CmdletBinding()]
param(
        [Parameter(Mandatory = $true)]$ApplicationId, 
        [Parameter(Mandatory = $true)]$SecurePassword,
        [Parameter(Mandatory = $true)]$TenantId,
        [Parameter(Mandatory = $true)]$KeyVault,
        [Parameter(Mandatory = $true)]$ServicePrincipal
   	)

begin
{
    write-host `KeyVault Name          :  $KeyVault
    write-host `service Principal Name :  $ServicePrincipal
}

process
{   
    Write-host "*****Task Open: Fetching the Service Principal details for an API*****"
	
	try {

        Write-host "*****Task 2: Az-Login using Service principal*****"
    	  az login --service-principal --username $ApplicationId --password $SecurePassword --tenant  $TenantId
	      
        $vaultId = (Get-AzureKeyVaultSecret -VaultName $KeyVault -Name $ServicePrincipal).Attributes.ContentType

        $vaultSecret = (Get-AzureKeyVaultSecret -VaultName $KeyVault -Name $ServicePrincipal).SecretValueText

        write-host "vault.client_id     : "  $vaultId
        write-host "vault.client_secret : "  $vaultSecret
                
        if($vaultId)  {
          Write-Host "##vso[task.setvariable variable=vault_client_id]$vaultId"
        }
        if($vaultSecret) {
          Write-Host "##vso[task.setvariable variable=vault_client_secret]$vaultSecret"
        }
      }

	catch {
          Write-Host $_.Exception.Message -ForegroundColor Red
		      Exit 1
	}
}

end
{
    Write-host "*****Task Complete:Fetched the Service Principal details for an API*****"
}