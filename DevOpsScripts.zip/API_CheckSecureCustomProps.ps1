﻿[CmdletBinding()]
param(
       [Parameter(Mandatory = $true)]$ConfigFilePath,
       [Parameter(Mandatory = $true)]$ConfigProperty,
       $filepattern = "secure"
     )

begin
{
    write-host `Config File Path        :  $ConfigFilePath
    write-host `Config File property    :  $ConfigProperty
}

process
{   
    Write-host "*****Task Open: Checking for the Secure Custom Properties in the Config File*****"
	
	try {
            if(Test-path -Path $ConfigFilePath) {
                $res = ''
                write-host "File exists in the path $ConfigFilePath"
                $fileContent = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
                $propvalue = $fileContent.$ConfigProperty
                $res = $propvalue.psobject.properties.name | select-string -Pattern 'secure' 
                               
                    if($res) {
                        $securepropsexists = "true"
                        Write-host "Secure Custom Properties defined in the Config file"
                    }
                    else
                    {   
                        $securepropsexists = "false"
                        write-host "No Secure Custom Properties defined in the Config file"
                    }
                    Write-Host "##vso[task.setvariable variable=securepropsexists]$securepropsexists"
                }    
                else
            {
                write-host "Cannot find the file in the path: $ConfigFilePath"
            }
        }

	catch {
             Write-Host $_.Exception.Message -ForegroundColor Red
		     Exit 1
	}
}

end
{
    Write-host "*****Task Complete:Checking for the Secure Custom Properties in the Config File*****"
}