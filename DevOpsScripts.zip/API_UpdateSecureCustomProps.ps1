﻿param(
         [Parameter(Mandatory = $true)]$ConfigFilePath,
         [Parameter(Mandatory = $true)]$ConfigProperty,
         [Parameter(Mandatory = $true)]$environment
     )

begin
{
    write-host `Config File Path        :  $ConfigFilePath
    write-host `Config File property    :  $ConfigProperty
    write-host `Environment             :  $environment
}

process
{   
    Write-host "*****Task Open: Fetching the list of pipeline variables*****"
	
	try {
            if(Test-path -Path $ConfigFilePath) {
                write-host "File exists in the path $ConfigFilePath"
                $fileContent = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
                
                write-host Get-ChildItem -Recurse Env: | Where-Object { $_.Name -like "*"+ $environment } 
                $envvariables= Get-ChildItem -Recurse Env: | Where-Object { $_.Name -like "*"+ $environment } 
                $env = $envvariables | Out-string
                write-host $env 
                
                $environment = "." + $environment
                write-host "Total Number of Secure Properties: " $envvariables.count
                if($envvariables.count -eq 0) {
                    write-host "No Secure Custom properties defined in the Pipeline variables"
               } 
                elseif($envvariables.count -gt 1) {  
                    $envvariables.GetEnumerator() | ForEach-Object{
                        $_.key =  $($_.key) -ireplace '_', '.'
                        $_.key =  $($_.key) -ireplace [regex]::Escape($environment), '' 
                       
                        if ($_.key -ne "prop.vault.key")  {
                            if (($fileContent.$ConfigProperty.psobject.properties | Foreach {$_.Name}) -icontains $_.key) {
                                write-host $_.key "found in the $ConfigFilePath"
                                $prop = $_.key
                                $fileContent.$ConfigProperty.$prop = $_.Value
                            }
                            else
                            {
                                write-host $_.key "missing in the $ConfigFilePath"
                                Exit 1
                            }
                       }
                    }
                }
                else {
                       $envvariables = $envvariables | Select-Object Name,Value |  ConvertTo-Json
                       $envvariables =  $envvariables -ireplace '_', '.' 
                       $x =  $envvariables -ireplace [regex]::Escape($environment), '' | ConvertFrom-Json
                                      
                       if ($x.Name -ne "prop.vault.key")  {
                             if (($fileContent.$ConfigProperty.psobject.properties | Foreach {$_.Name}) -icontains $x.Name) {
                                write-host $x.Name "found in the $ConfigFilePath"
                                $prop = $x.Name
                                $fileContent.$ConfigProperty.$prop = $x.Value
                            }
                            else
                            {
                                write-host $x.Name "missing in the $ConfigFilePath"
                                Exit 1
                            }

                         }
                     }
               $fileContent | Convertto-json | set-content $ConfigFilePath
               }
            
            else 
            {
                write-host "Cannot find the file in the path: $ConfigFilePath"
            }
           
        }

	catch {
             write-host $_.Exception.Message -ForegroundColor Red
			 $errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
			 write-host $errorresponse -ForegroundColor Red
		     Exit 1
	}

}
end
{
    Write-host "*****Task Complete:Updated the Property Name in the config file path*****"
}