﻿[CmdletBinding()]
param(
      [Parameter(Mandatory = $true)]$PomFilePath
   	)

begin
{
    write-host `Pom File Path   :  $PomFilePath
}

process
{   
    Write-host "*****Task Open: Fetching the Application name from the POM.xml*****"
	
	try {
            if(Test-path -Path $PomFilePath) {
                write-host "Pom.Xml file exists in the path $PomFilePath"
                $Pom_XMlContent = [xml](Get-Content -Path $PomFilePath)
                write-output $Pom_XMlContent
                $apiname = $Pom_XMlContent.project.name
                $apiname

                if($apiname) {
                    write-host "Mule Application Name: " $apiname
                    Write-Host "##vso[task.setvariable variable=apiname]$apiname"
                }
                else 
                {
                    write-host "Mule Application Name - 'name' is missing in the project POM.xml"
                    Exit 1
                }
            }
            else
            {
                write-host "Cannot find the POM.xml in the path: $PomFilePath"
                Exit 1
            }
        }

	catch {
             Write-Host $_.Exception.Message -ForegroundColor Red
		     Exit 1
	}
}

end
{
    Write-host "*****Task Complete:Fetched the Application Name from the POM.xml*****"
}