﻿[CmdletBinding()]
param(
      [Parameter(Mandatory = $true)]$ConfigFilePath,
      [Parameter(Mandatory = $true)]$ConfigProperty,
      $ConfigPropertyvalue
   	)

begin
{
    write-host `Config File Path        :  $ConfigFilePath
    write-host `Config File property    :  $ConfigProperty
}

process
{   
    Write-host "*****Task Open: Fetching the value of the given parameter name*****"
	
	try {
            if(Test-path -Path $ConfigFilePath) {
                write-host "File exists in the path $ConfigFilePath"
                $fileContent = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
                write-output "File Content:" $fileContent
                $propvalue = $fileContent.$ConfigProperty
                
                if($ConfigPropertyvalue) {
                    $propvalue = $propvalue.$ConfigPropertyvalue
                }
                
                if($propvalue) {
                    write-host "Property Name : " $ConfigProperty.$configPropertyValue
                    write-host "Property value: " $propvalue
                    Write-Host "##vso[task.setvariable variable=propvalue]$propvalue"
                }
                elseif($propvalue -eq "") {
                    $propvalue = "empty"
                    write-host "$ConfigProperty.$configPropertyValue returned null in the $ConfigFilePath"
                    Write-Host "##vso[task.setvariable variable=propvalue]$propvalue"
                }
                else 
                {   
                    $propvalue = "notdefined"
                    Write-Host "##vso[task.setvariable variable=propvalue]$propvalue"
                    write-host "$ConfigProperty.$configPropertyValue is missing in the config file $ConfigFilePath"
                }
            }
            else
            {
                write-host "Cannot find the file in the path: $ConfigFilePath"
            }
        }

	catch {
             Write-Host $_.Exception.Message -ForegroundColor Red
		     Exit 1
	}
}

end
{
    Write-host "*****Task Complete:Fetched the Property Name from the config file path*****"
}