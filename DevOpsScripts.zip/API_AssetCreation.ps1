<#
.SYNOPSIS
This script is used to  Asset Creation  through API call
.PARAMETER ClientId
ClientId of the Mule API
.PARAMETER ClientSecret
ClientSecret of the Mule API    
.PARAMETER OrgId
Organization Id of the Mule API
.PARAMETER EnvId
Environment Id of the Mule API 
.PARAMETER apiName
Name of the API, including its environment, for example kcc-testrepo1-dev , where kcc-testrepo1 is an api name and -dev is its environment as defined in mulesoft portal

.\API_AssetCreation.ps1 -apiName kcc-ps-sapewmpue-emea-sys-api -ClientId 'e6a44d5728f84ed4b420b5644c6b6e67' -ClientSecret '105732f2a917496eA60e58A438C9c83C' -OrgId '33cc9dc5-4aaf-4afe-9ad0-ef3b9c86bbfc' -EnvId 'bf2d2d0a-13ab-49ee-a1f1-50d0fad4fed1' 
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]$ClientId,
    [Parameter(Mandatory = $true)]$ClientSecret,
    [Parameter(Mandatory = $true)]$OrgId,
    [Parameter(Mandatory = $true)]$EnvId,
    [Parameter(Mandatory = $true)]$apiName
)

begin {

    write-host `Api Name    :  $apiName
 }

process {
            $AnyPointUrl = "https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token" ;
            $GrantType = "client_credentials";
            $ContentType = "application/x-www-form-urlencoded"
            $TokenRequestPayload = "client_id=$ClientId&client_secret=$ClientSecret&grant_type=$GrantType"
            # write-host "Token Request Payload :" $TokenRequestPayload
                                  
        try {
                #Get the access_token parameter from the Get Anypoint Url
                $Tokenresponse = Invoke-RestMethod -Uri $AnyPointUrl -Method POST -Body $TokenRequestPayload -ContentType $ContentType -ErrorVariable oErr;
                # Write-Host "Token response :" $Tokenresponse
                             
                $Bearertoken = $Tokenresponse.access_token
                Write-Host "Bearer token   :" $Bearertoken
                $Headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
                $Headers.Add("Authorization", "Bearer $Bearertoken") 
            } 
        catch {
                write-host "Failed to get the Bearer Token for the $AnyPointUrl !" -ForegroundColor Red
                write-host $_.Exception.Message -ForegroundColor Red
            }

    try{
            # Get the asset details from exchange
            $assetapi= "https://anypoint.mulesoft.com/exchange/api/v2/assets/search?Search=$apiName&organizationId=$OrgId"
            $Getasset = Invoke-RestMethod   -Uri $assetapi -Method Get  -Headers $Headers 
            $List=$Getasset.Where({$_.assetId -eq $apiName})
            $assetId = $List.assetId
            $version = $List.version
            $groupId = $List.groupId
            $type    = $List.type
            Write-Host "API version:" $version
        }
    catch{
        write-host "failed while getting the asset details from  $assetapi !" -ForegroundColor Red
        write-host $_.Exception.Message -ForegroundColor Red
    }
    if ($type -eq "rest-api") {   
    try{
            #Create asset in API manager
            $Body = @{
                endpoint = @{ uri = "http://"+$assetId +".cloudhub.io/api"; proxyUri = $null; isCloudHub = $true ; muleVersion4OrAbove = $true}
                spec= @{ groupId = $groupId ; assetId= $assetId ; version = $version}
            } | convertto-json

        $Createassetapi= "https://anypoint.mulesoft.com/apimanager/api/v1/organizations/"+$OrgId+"/environments/"+$EnvId+"/apis"
        $Reponse = Invoke-RestMethod -Uri $Createassetapi -ContentType "application/json" -Method POST -Body $Body -Headers $Headers 
        $Assetid= $Reponse.assetId
        $assetversion = $Reponse.assetVersion
        $apiid=$Reponse.id
        write-host "Assetversion:" $assetversion  "ID:" $apiid
        return $apiid
    }
    catch{
        write-host "failed during assert creation from  $Createassetapi !" -ForegroundColor Red
        write-host $_.Exception.Message -ForegroundColor Red
    }  
 
        try{
            # Get the details of the asset created in API manager
            $Policyapi="https://anypoint.mulesoft.com/apimanager/api/v1/organizations/"+$OrgId+"/environments/"+$EnvId+"/apis/"+$apiid+"/policies"
            $Body = @{
                   pointcutData = $null
                   policyTemplateId = 310877
                   apiVersionId=  $apiid
                   groupId= "68ef9520-24e9-4cf2-b2f5-620025690913"
                   assetId= "client-id-enforcement"
                   assetVersion= "1.2.3"
                   configurationData= @{ 
                                      credentialsOriginHasHttpBasicAuthenticationHeader ="customExpression"
                                      clientIdExpression = "#[attributes.headers['client_secret']]" 
                                      clientSecretExpression ="#[attributes.headers['client_id']]"
                                      }
                   } | ConvertTo-Json
            Invoke-RestMethod   -Uri $Policyapi  -ContentType "application/json" -Method POST -Body $Body -Headers $Headers 
        }
    catch{
        $Errormsg=$_.Exception.Message
        if( $Errormsg.contains('Conflict'))
                {
                    write-host "Policy existed for" $apiName -ForegroundColor Red
                }
        else{

            write-host $_.Exception.Message -ForegroundColor Red
            write-host "failed while applying policy to created assert " -ForegroundColor Red
        }
           
            

        }
        } 
    else {
        write-host "The Given API is an Application Type"
        }  
    }


end {
        Write-host "`n ####### --- Task Complete: Creating asset  is Complete --- ######## `n"
}