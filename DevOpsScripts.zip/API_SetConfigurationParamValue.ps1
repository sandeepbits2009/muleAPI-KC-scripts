﻿
param(
      [Parameter(Mandatory = $true)]$ConfigFilePath,
      [Parameter(Mandatory = $true)]$ConfigProperty,
      [Parameter(Mandatory = $true)]$UpdateValue,
      $ConfigPropertyvalue
   	)

begin
{
    write-host `Config File Path        :  $ConfigFilePath
    write-host `Config File property    :  $ConfigProperty
    write-host `Update value            :  $UpdateValue
    if($ConfigPropertyvalue) {
        write-host `Config File property Second level   :  $ConfigPropertyvalue
    }
}

process
{   
    Write-host "*****Task Open: Fetching the value of the given parameter name*****"
	
	try {
            if(Test-path -Path $ConfigFilePath) {
                write-host "File exists in the path $ConfigFilePath"
                $fileContent = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
                
                if($ConfigPropertyvalue) {
                    write-host "Config File property Second level exists"
                    $fileContent.$ConfigProperty.$ConfigPropertyvalue = $UpdateValue
                }
                else {
                    $fileContent.$ConfigProperty = $updateValue
                    write-host "ConfigProperty exists"
               }
                                           
               $fileContent | Convertto-json | set-content $ConfigFilePath
            }
            else 
            {
                write-host "Cannot find the file in the path: $ConfigFilePath"
            }
        }

	catch {
             write-host $_.Exception.Message -ForegroundColor Red
			 $errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
			 write-host $errorresponse -ForegroundColor Red
		     Exit 1
	}
}

end
{
    Write-host "*****Task Complete:Updated the Property Name in the config file path*****"
}