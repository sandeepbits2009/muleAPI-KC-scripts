﻿function Get-BearerAccessToken {
  
   [cmdletbinding()]
    param (
             [parameter(Mandatory = $true)][string]$ClientId,
             [parameter(Mandatory = $true)][string]$ClientSecret
    )

    begin {
               Write-Host "Function Entry: Get-BearerAccessToken"
               Write-Host "*************************************"
    }
    process {               
               $AnyPointUrl         = "https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token" ;
               $GrantType           = "client_credentials";
               $ContentType         = "application/x-www-form-urlencoded"
               $TokenRequestPayload = "client_id=$ClientId&client_secret=$ClientSecret&grant_type=$GrantType"
               write-host "Token Request Payload :" $TokenRequestPayload
                             
               try {
                        #Get the access_token parameter from the Get Anypoint Url
                        $Tokenresponse = Invoke-RestMethod -Uri $AnyPointUrl -Method POST -Body $TokenRequestPayload -ContentType $ContentType -ErrorVariable oErr;
                        Write-Host "Token response :" $Tokenresponse
                        
                        $Bearertoken = $Tokenresponse.access_token
                        Write-Host "Bearer token   :" $Bearertoken
                        return $Bearertoken
               } 
               catch {
                        write-host "Failed to get the Bearer Token for the $AnyPointUrl !" -ForegroundColor Red
                        write-host $_.Exception.Message -ForegroundColor Red
						$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
                        write-host $errorresponse -ForegroundColor Red
		                Exit 1
               }
    }
    end {
            Write-Host "Function Exit: Get-BearerAccessToken"
            Write-Host "*************************************"
    }
}


  $ClientId      = $args[0]
  $ClientSecret  = $args[1]
  $OrgId         = $args[2]
  $EnvId         = $args[3]
  $domain        = $args[4]
 
  # Getting the Bearer Access Token        
  $Bearertoken = Get-BearerAccessToken -ClientId $clientId -ClientSecret $ClientSecret
  Write-Host "Bearertoken   :" $Bearertoken

  $ApplicationUrl  = "https://anypoint.mulesoft.com/cloudhub/api/v2/applications/$domain" ;
  $Headers     = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $Headers.Add("Authorization", "Bearer $Bearertoken")
  $Headers.Add("X-ANYPNT-ORG-ID" , "$OrgId")
  $Headers.Add("X-ANYPNT-ENV-ID" , "$EnvId")
          
  #Get the access_token parameter from the Get Anypoint Url     
  try {
        $Initialresponse = Invoke-RestMethod -Uri $ApplicationUrl -Method GET -Headers $Headers -ErrorAction stop -ErrorVariable oErr
        $Initialstate    = $Initialresponse.domain
        $InitialStatus   = $Initialresponse.status
        if($Initialstate) {
            $apiexists = 0
            Write-host "Application Deployment Status : " $InitialStatus
        }
      }

  catch{
        $statusCodeValue = $_.Exception.Response.StatusCode.value__
        write-host $_.Exception.Message -ForegroundColor Red
		$errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
        write-host $errorresponse -ForegroundColor Red
        $apiexists = 1
        Write-host "Application not deployed"
  }
      
  Write-Host "##vso[task.setvariable variable=apiexists]$apiexists"
  Write-Host "##vso[task.setvariable variable=InitialStatus]$InitialStatus"