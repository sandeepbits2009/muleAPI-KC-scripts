﻿[CmdletBinding()]
    param(
       [Parameter(Mandatory = $true)]$SonarServerName,
       [Parameter(Mandatory = $true)]$SonarToken,
       [Parameter(Mandatory = $true)]$SonarProjectKey
    )

    begin
    {
        write-host `SonarServerName    :  $SonarServerName
        write-host `SonarProjectKey    :  $SonarProjectKey  
    }

    process
    {   
     #region to skip sonarqube cert errors
        add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@

        [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
        #endregion
        Write-host "*****Task Open: Creating Project in SonarQube *****"
        $Url = "$SonarServerName/api/projects/create"
        try {
            $Token = [System.Text.Encoding]::UTF8.GetBytes($SonarToken + ":")
            $TokenInBase64 = [System.Convert]::ToBase64String($Token)
            $basicAuth = [string]::Format("Basic {0}", $TokenInBase64)
            $Headers = @{ Authorization = $basicAuth }
            
            $pjtbody = @{
                projects = "$SonarProjectKey"
                
            }
            $pjturl = "$SonarServerName/api/projects/search"
            $PjtResult = Invoke-RestMethod -Uri $pjturl -Method 'GET' -Headers $headers -Body $pjtbody -Verbose 
            write-host $PjtResult.components.key 

            if(!$PjtResult.components.key) {

                $body = @{
                    project = "$SonarProjectKey"
                    name = "$SonarProjectKey"
                }
            
                $ProjectCreationResult = Invoke-RestMethod -Uri $url -Method 'Post' -Headers $headers -Body $body
            
                write-host "Successfully created the Project $SonarProjectKey !!"
            }
            else
            {
               write-host "$SonarProjectKey already exists, skipping!!"
            }

        }

        catch {
            write-host "Failed to create the Project in SonarQube !" -ForegroundColor Red
            write-host $_.Exception.Message -ForegroundColor Red
            write-host $_.Exception.ItemName -ForegroundColor Red
            Exit 1
        }
        
    }

    end
    {
        Write-host "***** Task Complete:Creation of the Project in SonarQube *****"
    }
