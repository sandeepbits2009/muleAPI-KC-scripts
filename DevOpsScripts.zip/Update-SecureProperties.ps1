<#
.SYNOPSIS
This script is used to reset/Update the API ARM json secret or passowrd through API call
.PARAMETER ClientId
ClientId of the Mule API
.PARAMETER ClientSecret
ClientSecret of the Mule API    
.PARAMETER OrgId
Organization Id of the Mule API
.PARAMETER EnvId
Environment Id of the Mule API 
.PARAMETER apiName
Name of the API, including its environment, for example kcc-testrepo1-dev , where kcc-testrepo1 is an api name and -dev is its environment as defined in mulesoft portal
.PARAMETER ConfigProperty
ConfigProperty is a configuration block  defined in the APi arm json, it is not a mandatory parameter but if required specific block value to be updated, can be mentioned here
.PARAMETER SecureProperty
SecureProperty is the name to seach in the API arm json, like username for which the corresponding password required to be updated
.PARAMETER SecureValue
Secure Value is the updated secet or password which needs to be updated for in the api configuration json
.EXAMPLE
.\Update-Keyvalue.ps1 -apiName kcc-Api -ClientId 'e6a44d5728f84ed4b420b5644c6b6e67' -ClientSecret '105732f2a917496eA60e58A438C9c83C' -OrgId '33cc9dc5-4aaf-4afe-9ad0-ef3b9c86bbfc' -EnvId 'bf2d2d0a-13ab-49ee-a1f1-50d0fad4fed1' -SecureProperty sfdcPassword -SecureValue dummyvalue2 -ConfigProperty properties
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]$ClientId,
    [Parameter(Mandatory = $true)]$ClientSecret,
    [Parameter(Mandatory = $true)]$OrgId,
    [Parameter(Mandatory = $true)]$EnvId,
    [Parameter(Mandatory = $true)]$apiName,
    [Parameter(Mandatory = $false)]$ConfigProperty,
    [Parameter(Mandatory = $true)]$SecureProperty,
    [Parameter(Mandatory = $true)]$SecureValue

)

begin {
    write-host `Config File property    :  $ConfigProperty
    write-host `SecureProperty to search:  $SecureProperty
    write-host `Api Name                :  $apiName
    
}

process {
    function Get-BearerAccessToken {
        [cmdletbinding()]
        param (
            [parameter(Mandatory = $true)][string]$ClientId,
            [parameter(Mandatory = $true)][string]$ClientSecret
        )
     
        begin {
            Write-Host "Function Entry: Get-BearerAccessToken"
            Write-Host "*************************************"
        }
        process {               
            $AnyPointUrl = "https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token" ;
            $GrantType = "client_credentials";
            $ContentType = "application/x-www-form-urlencoded"
            $TokenRequestPayload = "client_id=$ClientId&client_secret=$ClientSecret&grant_type=$GrantType"
            # write-host "Token Request Payload :" $TokenRequestPayload
                                  
            try {
                #Get the access_token parameter from the Get Anypoint Url
                $Tokenresponse = Invoke-RestMethod -Uri $AnyPointUrl -Method POST -Body $TokenRequestPayload -ContentType $ContentType -ErrorVariable oErr;
                # Write-Host "Token response :" $Tokenresponse
                             
                $Bearertoken = $Tokenresponse.access_token
                Write-Host "Bearer token   :" $Bearertoken
                return $Bearertoken
            } 
            catch {
                write-host "Failed to get the Bearer Token for the $AnyPointUrl !" -ForegroundColor Red
                write-host $_.Exception.Message -ForegroundColor Red
                $errorresponse = $oErr.Message | ConvertFrom-Json | Out-string
                write-host $errorresponse -ForegroundColor Red
                Exit 1
            }
        }
        end {
            Write-Host "Function Exit: Get-BearerAccessToken"
            Write-Host "*************************************"
        }
    }
    # Getting BearerToken        
    $Bearertoken = Get-BearerAccessToken -ClientId $clientId -ClientSecret $ClientSecret
    
    write-host ################# -----   Get Mule Rest API Property json   ------ ######################
    
    $APIUpdateStatusUrl = "https://anypoint.mulesoft.com/cloudhub/api/v2/applications/$apiName";
    write-host "API Update Status Url : " $APIUpdateStatusUrl
    Add-Type -AssemblyName System.Net.Http
    $Headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $Headers.Add("Authorization", "Bearer $Bearertoken")
    $Headers.Add("X-ANYPNT-ORG-ID" , "$OrgId")
    $Headers.Add("X-ANYPNT-ENV-ID" , "$EnvId")
    $GetApiProp = Invoke-RestMethod -Method Get -Uri $APIUpdateStatusUrl -Headers $Headers -ContentType "application/json"
    $GetApiProp = $GetApiProp | ConvertTo-Json  
    $GetApiProp | Out-File "$env:Agent_BuildDirectory\$apiName.json"
    # write-host "Json File Content: " $GetApiProp 
    $ConfigFilePath = "$env:Agent_BuildDirectory\$apiName.json"
    write-host `Config File Path :  $ConfigFilePath
    
    write-host "`n ############ ----- Reset API Properties for the API template ------ ################# `n"
    
    if (Test-path -Path $ConfigFilePath) {
        write-host "File exists in the path $ConfigFilePath"
        $fileContent = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
        $jsonAsHash = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json -AsHashtable
        if ($null -ne $ConfigProperty) {
            if ($($jsonAsHash.Keys) -contains $ConfigProperty) {
                if (($fileContent.$ConfigProperty.psobject.properties | ForEach-Object { $_.Name }) -icontains $SecureProperty) {
                    write-host  $SecureProperty "found in the mule-api $apiName configuration and updated the new value"
                    $fileContent.$ConfigProperty.$SecureProperty = $SecureValue
                    #$fileName = Split-Path $ConfigFilePath -Leaf
                }
                else {
                    write-host $SecureProperty "Secure Custom Property dosen't exist in the mule-api $apiName ARM property configuration block $ConfigProperty"
                    Exit 1
                }
            }
            else {
                write-host $ConfigProperty "Properties block is missing for the mule-api $apiName"
                Exit 1
            }
        }
        else {
            foreach ($param in $($jsonAsHash.Keys)) {
                $ConfigProperty = $param.trim()
                if (($fileContent.$ConfigProperty.psobject.properties | ForEach-Object { $_.Name }) -icontains $SecureProperty) {
                    write-host  $_.Name "`n found in the mule-api $apiName configuration block $ConfigProperty `n"
                    $fileContent.$ConfigProperty.$SecureProperty = $SecureValue
                    #$fileName = Split-Path $ConfigFilePath -Leaf
                    write-host "Name $SecureProperty found and its corresponding Secure Property Value has been Updated `n"
                    if ($fileContent.$ConfigProperty.$SecureProperty -eq $SecureValue) { break }
                }
                else {
                    write-host $SecureProperty "dosen't exist in the mule-api $apiName properties block $ConfigProperty, searching $SecureProperty ...."
                }
            }
        }
        $fileContent | Convertto-json | set-content $ConfigFilePath
        $updateApi = Get-Content $ConfigFilePath
    }
    $UpdateApiProp = Invoke-RestMethod -Method PUT -Uri $APIUpdateStatusUrl -Headers $Headers -Body $UpdateApi -ContentType "application/json" -ErrorVariable oErr; 
    $UpdateApiProp = $UpdateApiProp | ConvertTo-Json -AsArray 
}

end {
    Write-host "`n ####### --- Task Complete: Updating the Secure Custom Property $ConfigProperty Value for $apiName is Complete --- ######## `n"
}